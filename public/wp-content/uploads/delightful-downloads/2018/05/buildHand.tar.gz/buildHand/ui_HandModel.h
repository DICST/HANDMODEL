/********************************************************************************
** Form generated from reading UI file 'HandModel.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HANDMODEL_H
#define UI_HANDMODEL_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDockWidget>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QTreeView>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_HandModel
{
public:
    QAction *actionSave_Project;
    QAction *actionLoad_Project;
    QAction *actionSet_Workspace_Directory;
    QAction *actionOpen;
    QAction *actionExport;
    QAction *actionQuit;
    QAction *actionImport;
    QAction *actionWizardMode;
    QAction *actionBrowser;
    QAction *actionLayers;
    QAction *actionRaster_Data;
    QAction *actionRaster_Analysis_2;
    QAction *actionAbout_Qt;
    QAction *actionAbout_HAND;
    QAction *actionWizard;
    QAction *actionRaster_Analysis;
    QAction *actionHAND_Contour;
    QAction *actionSlope;
    QAction *actionDrainage;
    QAction *actionACC;
    QAction *actionHAND;
    QAction *actionColor;
    QAction *actionDEMC;
    QAction *actionCMASK;
    QAction *actionHCHAN;
    QWidget *centralWidget;
    QHBoxLayout *horizontalLayout;
    QFrame *frameView;
    QMenuBar *menuBar;
    QMenu *menuFile;
    QMenu *menuView;
    QMenu *menuHelp;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;
    QDockWidget *dockWidgetBrowser;
    QWidget *dockContentsBrowser;
    QVBoxLayout *verticalLayout;
    QTreeView *browserView;
    QDockWidget *dockWidgetLayer;
    QWidget *dockContentsImage;
    QGridLayout *gridLayout_2;
    QListView *loadedListImageView;
    QFrame *frameBt;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *pbimgUp;
    QPushButton *pbimgDown;
    QPushButton *pbimgRemove;
    QPushButton *pbimgFit;
    QPushButton *pbimgInfo;
    QSpacerItem *horizontalSpacer_2;
    QDockWidget *dockWidgetRasterData;
    QWidget *dockWidgetContents;
    QVBoxLayout *verticalLayout_2;
    QTableWidget *tableWidgetRasterData;
    QDockWidget *dockWidgetAnalysis;
    QWidget *dockWidgetContentsAnalysis;
    QGridLayout *gridLayout;
    QPushButton *pushButtonOk;
    QComboBox *comboBoxRoutines;
    QPushButton *pushButtonCancel;
    QCheckBox *checkBoxLoadOutput;
    QSpacerItem *horizontalSpacer;
    QStackedWidget *stackedWidgetRoutines;
    QWidget *pageCorrectDem;
    QGridLayout *gridLayout_3;
    QSpacerItem *verticalSpacer;
    QLineEdit *lineEditOut_LDD;
    QPushButton *pushButtonSet_LDD;
    QLabel *label_19;
    QRadioButton *radioButtonFill;
    QLabel *label_40;
    QComboBox *comboBoxInDEM;
    QLineEdit *lineEditOut_DEMC;
    QFrame *line;
    QPushButton *pushButtonSet_DEMC;
    QRadioButton *radioButtonBreaching;
    QFrame *line_8;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_39;
    QLabel *label_56;
    QLabel *label;
    QWidget *pageFlowAccumulation;
    QGridLayout *gridLayout_4;
    QLabel *label_6;
    QSpacerItem *verticalSpacer_2;
    QLabel *label_5;
    QLineEdit *lineEditOut_ACC;
    QComboBox *comboBoxInLDD;
    QPushButton *pushButtonSet_ACC;
    QLabel *label_37;
    QFrame *line_7;
    QLabel *label_38;
    QWidget *pageDrainageNetwork;
    QGridLayout *gridLayout_5;
    QLabel *label_4;
    QPushButton *pushButtonSet_DREN;
    QLabel *label_7;
    QCheckBox *checkBoxThreshold;
    QLabel *labelThresholdCalc;
    QComboBox *comboBoxInDEMC;
    QComboBox *comboBoxInLDD_2;
    QSpinBox *spinBoxThreshold;
    QLabel *label_10;
    QLineEdit *lineEditOut_DREN;
    QComboBox *comboBoxInACC;
    QLabel *label_9;
    QLabel *label_8;
    QLabel *label_34;
    QLabel *label_33;
    QFrame *line_6;
    QSpacerItem *verticalSpacer_10;
    QFrame *line_5;
    QLabel *label_35;
    QLabel *label_36;
    QWidget *pageHAND;
    QGridLayout *gridLayout_6;
    QComboBox *comboBoxInDREN;
    QLabel *label_14;
    QLabel *label_11;
    QComboBox *comboBoxInLDD_3;
    QLabel *label_13;
    QSpacerItem *verticalSpacer_3;
    QLineEdit *lineEditOut_HAND;
    QComboBox *comboBoxInDEM_2;
    QLabel *label_12;
    QPushButton *pushButtonSet_HAND;
    QLabel *label_31;
    QFrame *line_4;
    QLabel *label_32;
    QWidget *pageSlopePercentage;
    QGridLayout *gridLayout_7;
    QLabel *label_16;
    QLabel *label_15;
    QLineEdit *lineEditOut_SLOPE;
    QSpacerItem *verticalSpacer_4;
    QComboBox *comboBoxInDEM_3;
    QCheckBox *checkBoxSlopePercentage;
    QPushButton *pushButtonSet_DEM_2;
    QFrame *line_14;
    QLabel *label_49;
    QFrame *line_15;
    QLabel *label_50;
    QWidget *pageClassification;
    QGridLayout *gridLayout_8;
    QLabel *label_17;
    QPushButton *pushButtonSet_CLASS;
    QLineEdit *lineEditOut_CLASS;
    QSpacerItem *verticalSpacer_5;
    QFrame *frameScript;
    QGridLayout *gridLayout_9;
    QPushButton *pushButtonDelColor;
    QPushButton *pushButtonAdd;
    QPushButton *pushButtonRemove;
    QSpacerItem *verticalSpacer_6;
    QTableWidget *tableWidgetScript;
    QPushButton *pushButtonSaveColor;
    QFrame *line_2;
    QComboBox *comboBoxColor;
    QFrame *line_13;
    QWidget *pageHANDContour;
    QGridLayout *gridLayout_11;
    QComboBox *comboBoxInHAND;
    QLabel *label_18;
    QLineEdit *lineEditOut_HANDC;
    QLabel *label_21;
    QPushButton *pushButtonSet_HANDC;
    QSpacerItem *verticalSpacer_7;
    QLabel *label_25;
    QSpinBox *spinBoxWidth;
    QFrame *line_12;
    QLabel *label_47;
    QFrame *line_11;
    QLabel *label_46;
    QLabel *label_48;
    QLabel *label_53;
    QSpinBox *spinBoxOffset;
    QWidget *pageHANDChannel;
    QGridLayout *gridLayout_12;
    QLabel *label_24;
    QLabel *label_45;
    QLabel *label_20;
    QPushButton *pushButtonSet_HCHAN;
    QLabel *label_23;
    QComboBox *comboBoxInDEM_4;
    QSpacerItem *verticalSpacer_8;
    QLabel *label_22;
    QLineEdit *lineEditOut_HCHAN;
    QComboBox *comboBoxInDREN_2;
    QComboBox *comboBoxInLDD_4;
    QFrame *line_10;
    QLabel *label_44;
    QWidget *pageChannelMask;
    QGridLayout *gridLayout_13;
    QPushButton *pushButtonSet_CMASK;
    QFrame *line_9;
    QLabel *label_43;
    QSpinBox *spinBoxFlood;
    QLineEdit *lineEditLon;
    QComboBox *comboBoxInLDD_5;
    QLabel *label_29;
    QComboBox *comboBoxInDREN_3;
    QLabel *label_28;
    QLabel *label_54;
    QLabel *label_42;
    QLineEdit *lineEditOut_CMASK2;
    QLineEdit *lineEditOut_CMASK;
    QFrame *line_3;
    QLabel *label_30;
    QLineEdit *lineEditLat;
    QPushButton *pushButtonSet_CMASK2;
    QSpacerItem *verticalSpacer_9;
    QLabel *label_27;
    QComboBox *comboBoxInDEM_5;
    QLabel *label_41;
    QLabel *label_52;
    QLabel *label_51;
    QLabel *label_26;
    QLabel *label_55;
    QComboBox *comboBoxInACC_2;

    void setupUi(QMainWindow *HandModel)
    {
        if (HandModel->objectName().isEmpty())
            HandModel->setObjectName(QStringLiteral("HandModel"));
        HandModel->resize(802, 652);
        actionSave_Project = new QAction(HandModel);
        actionSave_Project->setObjectName(QStringLiteral("actionSave_Project"));
        QIcon icon;
        icon.addFile(QStringLiteral(":/Resources/proj_save.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionSave_Project->setIcon(icon);
        actionLoad_Project = new QAction(HandModel);
        actionLoad_Project->setObjectName(QStringLiteral("actionLoad_Project"));
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/Resources/creatework.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionLoad_Project->setIcon(icon1);
        actionSet_Workspace_Directory = new QAction(HandModel);
        actionSet_Workspace_Directory->setObjectName(QStringLiteral("actionSet_Workspace_Directory"));
        QIcon icon2;
        icon2.addFile(QStringLiteral(":/Resources/worksp.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionSet_Workspace_Directory->setIcon(icon2);
        actionOpen = new QAction(HandModel);
        actionOpen->setObjectName(QStringLiteral("actionOpen"));
        actionExport = new QAction(HandModel);
        actionExport->setObjectName(QStringLiteral("actionExport"));
        actionExport->setEnabled(false);
        actionQuit = new QAction(HandModel);
        actionQuit->setObjectName(QStringLiteral("actionQuit"));
        actionImport = new QAction(HandModel);
        actionImport->setObjectName(QStringLiteral("actionImport"));
        actionImport->setEnabled(false);
        actionWizardMode = new QAction(HandModel);
        actionWizardMode->setObjectName(QStringLiteral("actionWizardMode"));
        QIcon icon3;
        icon3.addFile(QStringLiteral(":/Resources/wizard_ico.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionWizardMode->setIcon(icon3);
        actionBrowser = new QAction(HandModel);
        actionBrowser->setObjectName(QStringLiteral("actionBrowser"));
        actionBrowser->setCheckable(true);
        actionLayers = new QAction(HandModel);
        actionLayers->setObjectName(QStringLiteral("actionLayers"));
        actionLayers->setCheckable(true);
        actionRaster_Data = new QAction(HandModel);
        actionRaster_Data->setObjectName(QStringLiteral("actionRaster_Data"));
        actionRaster_Data->setCheckable(true);
        actionRaster_Analysis_2 = new QAction(HandModel);
        actionRaster_Analysis_2->setObjectName(QStringLiteral("actionRaster_Analysis_2"));
        actionRaster_Analysis_2->setCheckable(true);
        actionAbout_Qt = new QAction(HandModel);
        actionAbout_Qt->setObjectName(QStringLiteral("actionAbout_Qt"));
        actionAbout_HAND = new QAction(HandModel);
        actionAbout_HAND->setObjectName(QStringLiteral("actionAbout_HAND"));
        QIcon icon4;
        icon4.addFile(QStringLiteral(":/Resources/handlogo_icon.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionAbout_HAND->setIcon(icon4);
        actionWizard = new QAction(HandModel);
        actionWizard->setObjectName(QStringLiteral("actionWizard"));
        actionWizard->setIcon(icon3);
        actionRaster_Analysis = new QAction(HandModel);
        actionRaster_Analysis->setObjectName(QStringLiteral("actionRaster_Analysis"));
        actionRaster_Analysis->setCheckable(true);
        actionRaster_Analysis->setChecked(false);
        QIcon icon5;
        icon5.addFile(QStringLiteral(":/Resources/analy.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionRaster_Analysis->setIcon(icon5);
        actionHAND_Contour = new QAction(HandModel);
        actionHAND_Contour->setObjectName(QStringLiteral("actionHAND_Contour"));
        QIcon icon6;
        icon6.addFile(QStringLiteral(":/Resources/handContour.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionHAND_Contour->setIcon(icon6);
        actionSlope = new QAction(HandModel);
        actionSlope->setObjectName(QStringLiteral("actionSlope"));
        QIcon icon7;
        icon7.addFile(QStringLiteral(":/Resources/slope_ico.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionSlope->setIcon(icon7);
        actionDrainage = new QAction(HandModel);
        actionDrainage->setObjectName(QStringLiteral("actionDrainage"));
        QIcon icon8;
        icon8.addFile(QStringLiteral(":/Resources/drain_ico.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionDrainage->setIcon(icon8);
        actionACC = new QAction(HandModel);
        actionACC->setObjectName(QStringLiteral("actionACC"));
        QIcon icon9;
        icon9.addFile(QStringLiteral(":/Resources/acc_ico.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionACC->setIcon(icon9);
        actionHAND = new QAction(HandModel);
        actionHAND->setObjectName(QStringLiteral("actionHAND"));
        QIcon icon10;
        icon10.addFile(QStringLiteral(":/Resources/handlg.ico"), QSize(), QIcon::Normal, QIcon::Off);
        actionHAND->setIcon(icon10);
        actionColor = new QAction(HandModel);
        actionColor->setObjectName(QStringLiteral("actionColor"));
        QIcon icon11;
        icon11.addFile(QStringLiteral(":/Resources/square_ico.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionColor->setIcon(icon11);
        actionDEMC = new QAction(HandModel);
        actionDEMC->setObjectName(QStringLiteral("actionDEMC"));
        QIcon icon12;
        icon12.addFile(QStringLiteral(":/Resources/mapCor_ico.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionDEMC->setIcon(icon12);
        actionCMASK = new QAction(HandModel);
        actionCMASK->setObjectName(QStringLiteral("actionCMASK"));
        QIcon icon13;
        icon13.addFile(QStringLiteral(":/Resources/handchan.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionCMASK->setIcon(icon13);
        actionHCHAN = new QAction(HandModel);
        actionHCHAN->setObjectName(QStringLiteral("actionHCHAN"));
        QIcon icon14;
        icon14.addFile(QStringLiteral(":/Resources/hchan.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionHCHAN->setIcon(icon14);
        centralWidget = new QWidget(HandModel);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        horizontalLayout = new QHBoxLayout(centralWidget);
        horizontalLayout->setSpacing(0);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        frameView = new QFrame(centralWidget);
        frameView->setObjectName(QStringLiteral("frameView"));
        frameView->setFrameShape(QFrame::NoFrame);
        frameView->setFrameShadow(QFrame::Raised);
        frameView->setLineWidth(0);

        horizontalLayout->addWidget(frameView);

        HandModel->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(HandModel);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 802, 22));
        menuFile = new QMenu(menuBar);
        menuFile->setObjectName(QStringLiteral("menuFile"));
        menuView = new QMenu(menuBar);
        menuView->setObjectName(QStringLiteral("menuView"));
        menuHelp = new QMenu(menuBar);
        menuHelp->setObjectName(QStringLiteral("menuHelp"));
        HandModel->setMenuBar(menuBar);
        mainToolBar = new QToolBar(HandModel);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        mainToolBar->setEnabled(true);
        QFont font;
        font.setPointSize(10);
        mainToolBar->setFont(font);
        mainToolBar->setIconSize(QSize(32, 32));
        HandModel->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(HandModel);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        HandModel->setStatusBar(statusBar);
        dockWidgetBrowser = new QDockWidget(HandModel);
        dockWidgetBrowser->setObjectName(QStringLiteral("dockWidgetBrowser"));
        dockContentsBrowser = new QWidget();
        dockContentsBrowser->setObjectName(QStringLiteral("dockContentsBrowser"));
        verticalLayout = new QVBoxLayout(dockContentsBrowser);
        verticalLayout->setSpacing(2);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(2, 2, 2, 2);
        browserView = new QTreeView(dockContentsBrowser);
        browserView->setObjectName(QStringLiteral("browserView"));
        browserView->setMouseTracking(true);
        browserView->setIndentation(10);
        browserView->setAnimated(true);

        verticalLayout->addWidget(browserView);

        dockWidgetBrowser->setWidget(dockContentsBrowser);
        HandModel->addDockWidget(static_cast<Qt::DockWidgetArea>(1), dockWidgetBrowser);
        dockWidgetLayer = new QDockWidget(HandModel);
        dockWidgetLayer->setObjectName(QStringLiteral("dockWidgetLayer"));
        dockContentsImage = new QWidget();
        dockContentsImage->setObjectName(QStringLiteral("dockContentsImage"));
        gridLayout_2 = new QGridLayout(dockContentsImage);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        gridLayout_2->setContentsMargins(2, 2, 2, 2);
        loadedListImageView = new QListView(dockContentsImage);
        loadedListImageView->setObjectName(QStringLiteral("loadedListImageView"));

        gridLayout_2->addWidget(loadedListImageView, 0, 0, 1, 2);

        frameBt = new QFrame(dockContentsImage);
        frameBt->setObjectName(QStringLiteral("frameBt"));
        frameBt->setEnabled(false);
        frameBt->setFrameShape(QFrame::NoFrame);
        frameBt->setFrameShadow(QFrame::Raised);
        horizontalLayout_2 = new QHBoxLayout(frameBt);
        horizontalLayout_2->setSpacing(0);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(5, 0, 0, 5);
        pbimgUp = new QPushButton(frameBt);
        pbimgUp->setObjectName(QStringLiteral("pbimgUp"));
        QIcon icon15;
        icon15.addFile(QStringLiteral(":/Resources/arrow_up.png"), QSize(), QIcon::Normal, QIcon::Off);
        pbimgUp->setIcon(icon15);

        horizontalLayout_2->addWidget(pbimgUp);

        pbimgDown = new QPushButton(frameBt);
        pbimgDown->setObjectName(QStringLiteral("pbimgDown"));
        QIcon icon16;
        icon16.addFile(QStringLiteral(":/Resources/arrow_down.png"), QSize(), QIcon::Normal, QIcon::Off);
        pbimgDown->setIcon(icon16);

        horizontalLayout_2->addWidget(pbimgDown);

        pbimgRemove = new QPushButton(frameBt);
        pbimgRemove->setObjectName(QStringLiteral("pbimgRemove"));
        QIcon icon17;
        icon17.addFile(QStringLiteral(":/Resources/delete.png"), QSize(), QIcon::Normal, QIcon::Off);
        pbimgRemove->setIcon(icon17);

        horizontalLayout_2->addWidget(pbimgRemove);

        pbimgFit = new QPushButton(frameBt);
        pbimgFit->setObjectName(QStringLiteral("pbimgFit"));
        QIcon icon18;
        icon18.addFile(QStringLiteral(":/Resources/fit.png"), QSize(), QIcon::Normal, QIcon::Off);
        pbimgFit->setIcon(icon18);

        horizontalLayout_2->addWidget(pbimgFit);

        pbimgInfo = new QPushButton(frameBt);
        pbimgInfo->setObjectName(QStringLiteral("pbimgInfo"));
        QIcon icon19;
        icon19.addFile(QStringLiteral(":/Resources/info-icon (copy).png"), QSize(), QIcon::Normal, QIcon::Off);
        pbimgInfo->setIcon(icon19);

        horizontalLayout_2->addWidget(pbimgInfo);


        gridLayout_2->addWidget(frameBt, 1, 0, 1, 1);

        horizontalSpacer_2 = new QSpacerItem(137, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_2->addItem(horizontalSpacer_2, 1, 1, 1, 1);

        dockWidgetLayer->setWidget(dockContentsImage);
        HandModel->addDockWidget(static_cast<Qt::DockWidgetArea>(1), dockWidgetLayer);
        dockWidgetRasterData = new QDockWidget(HandModel);
        dockWidgetRasterData->setObjectName(QStringLiteral("dockWidgetRasterData"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(dockWidgetRasterData->sizePolicy().hasHeightForWidth());
        dockWidgetRasterData->setSizePolicy(sizePolicy);
        dockWidgetRasterData->setMinimumSize(QSize(120, 142));
        dockWidgetRasterData->setFloating(false);
        dockWidgetContents = new QWidget();
        dockWidgetContents->setObjectName(QStringLiteral("dockWidgetContents"));
        verticalLayout_2 = new QVBoxLayout(dockWidgetContents);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(2, 2, 2, 2);
        tableWidgetRasterData = new QTableWidget(dockWidgetContents);
        tableWidgetRasterData->setObjectName(QStringLiteral("tableWidgetRasterData"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(tableWidgetRasterData->sizePolicy().hasHeightForWidth());
        tableWidgetRasterData->setSizePolicy(sizePolicy1);
        tableWidgetRasterData->setMinimumSize(QSize(0, 0));
        QFont font1;
        font1.setPointSize(9);
        tableWidgetRasterData->setFont(font1);

        verticalLayout_2->addWidget(tableWidgetRasterData);

        dockWidgetRasterData->setWidget(dockWidgetContents);
        HandModel->addDockWidget(static_cast<Qt::DockWidgetArea>(1), dockWidgetRasterData);
        dockWidgetAnalysis = new QDockWidget(HandModel);
        dockWidgetAnalysis->setObjectName(QStringLiteral("dockWidgetAnalysis"));
        dockWidgetAnalysis->setMinimumSize(QSize(550, 561));
        dockWidgetAnalysis->setFeatures(QDockWidget::AllDockWidgetFeatures);
        dockWidgetContentsAnalysis = new QWidget();
        dockWidgetContentsAnalysis->setObjectName(QStringLiteral("dockWidgetContentsAnalysis"));
        gridLayout = new QGridLayout(dockWidgetContentsAnalysis);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(2, 0, 2, 6);
        pushButtonOk = new QPushButton(dockWidgetContentsAnalysis);
        pushButtonOk->setObjectName(QStringLiteral("pushButtonOk"));

        gridLayout->addWidget(pushButtonOk, 5, 2, 1, 1);

        comboBoxRoutines = new QComboBox(dockWidgetContentsAnalysis);
        comboBoxRoutines->setObjectName(QStringLiteral("comboBoxRoutines"));

        gridLayout->addWidget(comboBoxRoutines, 0, 0, 1, 3);

        pushButtonCancel = new QPushButton(dockWidgetContentsAnalysis);
        pushButtonCancel->setObjectName(QStringLiteral("pushButtonCancel"));

        gridLayout->addWidget(pushButtonCancel, 5, 1, 1, 1);

        checkBoxLoadOutput = new QCheckBox(dockWidgetContentsAnalysis);
        checkBoxLoadOutput->setObjectName(QStringLiteral("checkBoxLoadOutput"));
        QSizePolicy sizePolicy2(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(checkBoxLoadOutput->sizePolicy().hasHeightForWidth());
        checkBoxLoadOutput->setSizePolicy(sizePolicy2);
        checkBoxLoadOutput->setChecked(true);

        gridLayout->addWidget(checkBoxLoadOutput, 3, 0, 1, 3);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer, 5, 0, 1, 1);

        stackedWidgetRoutines = new QStackedWidget(dockWidgetContentsAnalysis);
        stackedWidgetRoutines->setObjectName(QStringLiteral("stackedWidgetRoutines"));
        stackedWidgetRoutines->setFrameShape(QFrame::StyledPanel);
        pageCorrectDem = new QWidget();
        pageCorrectDem->setObjectName(QStringLiteral("pageCorrectDem"));
        gridLayout_3 = new QGridLayout(pageCorrectDem);
        gridLayout_3->setSpacing(6);
        gridLayout_3->setContentsMargins(11, 11, 11, 11);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_3->addItem(verticalSpacer, 13, 1, 1, 1);

        lineEditOut_LDD = new QLineEdit(pageCorrectDem);
        lineEditOut_LDD->setObjectName(QStringLiteral("lineEditOut_LDD"));

        gridLayout_3->addWidget(lineEditOut_LDD, 8, 1, 1, 1);

        pushButtonSet_LDD = new QPushButton(pageCorrectDem);
        pushButtonSet_LDD->setObjectName(QStringLiteral("pushButtonSet_LDD"));

        gridLayout_3->addWidget(pushButtonSet_LDD, 8, 2, 1, 1);

        label_19 = new QLabel(pageCorrectDem);
        label_19->setObjectName(QStringLiteral("label_19"));
        QFont font2;
        font2.setBold(true);
        font2.setWeight(75);
        label_19->setFont(font2);

        gridLayout_3->addWidget(label_19, 10, 0, 1, 1);

        radioButtonFill = new QRadioButton(pageCorrectDem);
        radioButtonFill->setObjectName(QStringLiteral("radioButtonFill"));
        radioButtonFill->setChecked(true);

        gridLayout_3->addWidget(radioButtonFill, 11, 0, 1, 1);

        label_40 = new QLabel(pageCorrectDem);
        label_40->setObjectName(QStringLiteral("label_40"));
        label_40->setFont(font2);

        gridLayout_3->addWidget(label_40, 4, 0, 1, 1);

        comboBoxInDEM = new QComboBox(pageCorrectDem);
        comboBoxInDEM->setObjectName(QStringLiteral("comboBoxInDEM"));
        comboBoxInDEM->setAcceptDrops(true);
        comboBoxInDEM->setEditable(false);

        gridLayout_3->addWidget(comboBoxInDEM, 2, 1, 1, 1);

        lineEditOut_DEMC = new QLineEdit(pageCorrectDem);
        lineEditOut_DEMC->setObjectName(QStringLiteral("lineEditOut_DEMC"));

        gridLayout_3->addWidget(lineEditOut_DEMC, 5, 1, 1, 1);

        line = new QFrame(pageCorrectDem);
        line->setObjectName(QStringLiteral("line"));
        line->setMinimumSize(QSize(0, 10));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        gridLayout_3->addWidget(line, 9, 0, 1, 3);

        pushButtonSet_DEMC = new QPushButton(pageCorrectDem);
        pushButtonSet_DEMC->setObjectName(QStringLiteral("pushButtonSet_DEMC"));

        gridLayout_3->addWidget(pushButtonSet_DEMC, 5, 2, 1, 1);

        radioButtonBreaching = new QRadioButton(pageCorrectDem);
        radioButtonBreaching->setObjectName(QStringLiteral("radioButtonBreaching"));

        gridLayout_3->addWidget(radioButtonBreaching, 11, 1, 1, 1);

        line_8 = new QFrame(pageCorrectDem);
        line_8->setObjectName(QStringLiteral("line_8"));
        line_8->setFrameShape(QFrame::HLine);
        line_8->setFrameShadow(QFrame::Sunken);

        gridLayout_3->addWidget(line_8, 3, 0, 1, 3);

        label_2 = new QLabel(pageCorrectDem);
        label_2->setObjectName(QStringLiteral("label_2"));

        gridLayout_3->addWidget(label_2, 5, 0, 1, 1);

        label_3 = new QLabel(pageCorrectDem);
        label_3->setObjectName(QStringLiteral("label_3"));

        gridLayout_3->addWidget(label_3, 8, 0, 1, 1);

        label_39 = new QLabel(pageCorrectDem);
        label_39->setObjectName(QStringLiteral("label_39"));
        label_39->setFont(font2);

        gridLayout_3->addWidget(label_39, 1, 0, 1, 1);

        label_56 = new QLabel(pageCorrectDem);
        label_56->setObjectName(QStringLiteral("label_56"));

        gridLayout_3->addWidget(label_56, 2, 0, 1, 1);

        label = new QLabel(pageCorrectDem);
        label->setObjectName(QStringLiteral("label"));
        sizePolicy.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy);

        gridLayout_3->addWidget(label, 12, 0, 1, 2);

        stackedWidgetRoutines->addWidget(pageCorrectDem);
        pageFlowAccumulation = new QWidget();
        pageFlowAccumulation->setObjectName(QStringLiteral("pageFlowAccumulation"));
        gridLayout_4 = new QGridLayout(pageFlowAccumulation);
        gridLayout_4->setSpacing(6);
        gridLayout_4->setContentsMargins(11, 11, 11, 11);
        gridLayout_4->setObjectName(QStringLiteral("gridLayout_4"));
        label_6 = new QLabel(pageFlowAccumulation);
        label_6->setObjectName(QStringLiteral("label_6"));

        gridLayout_4->addWidget(label_6, 4, 0, 1, 1);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_4->addItem(verticalSpacer_2, 5, 1, 1, 1);

        label_5 = new QLabel(pageFlowAccumulation);
        label_5->setObjectName(QStringLiteral("label_5"));
        QSizePolicy sizePolicy3(QSizePolicy::Maximum, QSizePolicy::Preferred);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(label_5->sizePolicy().hasHeightForWidth());
        label_5->setSizePolicy(sizePolicy3);

        gridLayout_4->addWidget(label_5, 1, 0, 1, 1);

        lineEditOut_ACC = new QLineEdit(pageFlowAccumulation);
        lineEditOut_ACC->setObjectName(QStringLiteral("lineEditOut_ACC"));

        gridLayout_4->addWidget(lineEditOut_ACC, 4, 1, 1, 1);

        comboBoxInLDD = new QComboBox(pageFlowAccumulation);
        comboBoxInLDD->setObjectName(QStringLiteral("comboBoxInLDD"));

        gridLayout_4->addWidget(comboBoxInLDD, 1, 1, 1, 1);

        pushButtonSet_ACC = new QPushButton(pageFlowAccumulation);
        pushButtonSet_ACC->setObjectName(QStringLiteral("pushButtonSet_ACC"));

        gridLayout_4->addWidget(pushButtonSet_ACC, 4, 2, 1, 1);

        label_37 = new QLabel(pageFlowAccumulation);
        label_37->setObjectName(QStringLiteral("label_37"));
        label_37->setFont(font2);

        gridLayout_4->addWidget(label_37, 0, 0, 1, 1);

        line_7 = new QFrame(pageFlowAccumulation);
        line_7->setObjectName(QStringLiteral("line_7"));
        line_7->setFrameShape(QFrame::HLine);
        line_7->setFrameShadow(QFrame::Sunken);

        gridLayout_4->addWidget(line_7, 2, 0, 1, 3);

        label_38 = new QLabel(pageFlowAccumulation);
        label_38->setObjectName(QStringLiteral("label_38"));
        label_38->setFont(font2);

        gridLayout_4->addWidget(label_38, 3, 0, 1, 1);

        stackedWidgetRoutines->addWidget(pageFlowAccumulation);
        pageDrainageNetwork = new QWidget();
        pageDrainageNetwork->setObjectName(QStringLiteral("pageDrainageNetwork"));
        gridLayout_5 = new QGridLayout(pageDrainageNetwork);
        gridLayout_5->setSpacing(6);
        gridLayout_5->setContentsMargins(11, 11, 11, 11);
        gridLayout_5->setObjectName(QStringLiteral("gridLayout_5"));
        label_4 = new QLabel(pageDrainageNetwork);
        label_4->setObjectName(QStringLiteral("label_4"));

        gridLayout_5->addWidget(label_4, 2, 0, 1, 1);

        pushButtonSet_DREN = new QPushButton(pageDrainageNetwork);
        pushButtonSet_DREN->setObjectName(QStringLiteral("pushButtonSet_DREN"));

        gridLayout_5->addWidget(pushButtonSet_DREN, 7, 2, 1, 1);

        label_7 = new QLabel(pageDrainageNetwork);
        label_7->setObjectName(QStringLiteral("label_7"));

        gridLayout_5->addWidget(label_7, 1, 0, 1, 1);

        checkBoxThreshold = new QCheckBox(pageDrainageNetwork);
        checkBoxThreshold->setObjectName(QStringLiteral("checkBoxThreshold"));
        checkBoxThreshold->setChecked(true);

        gridLayout_5->addWidget(checkBoxThreshold, 11, 0, 1, 3);

        labelThresholdCalc = new QLabel(pageDrainageNetwork);
        labelThresholdCalc->setObjectName(QStringLiteral("labelThresholdCalc"));
        labelThresholdCalc->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);

        gridLayout_5->addWidget(labelThresholdCalc, 12, 0, 1, 3);

        comboBoxInDEMC = new QComboBox(pageDrainageNetwork);
        comboBoxInDEMC->setObjectName(QStringLiteral("comboBoxInDEMC"));

        gridLayout_5->addWidget(comboBoxInDEMC, 1, 1, 1, 1);

        comboBoxInLDD_2 = new QComboBox(pageDrainageNetwork);
        comboBoxInLDD_2->setObjectName(QStringLiteral("comboBoxInLDD_2"));

        gridLayout_5->addWidget(comboBoxInLDD_2, 2, 1, 1, 1);

        spinBoxThreshold = new QSpinBox(pageDrainageNetwork);
        spinBoxThreshold->setObjectName(QStringLiteral("spinBoxThreshold"));
        spinBoxThreshold->setMinimum(1);
        spinBoxThreshold->setMaximum(999999999);
        spinBoxThreshold->setValue(1);

        gridLayout_5->addWidget(spinBoxThreshold, 10, 1, 1, 1);

        label_10 = new QLabel(pageDrainageNetwork);
        label_10->setObjectName(QStringLiteral("label_10"));

        gridLayout_5->addWidget(label_10, 10, 0, 1, 1);

        lineEditOut_DREN = new QLineEdit(pageDrainageNetwork);
        lineEditOut_DREN->setObjectName(QStringLiteral("lineEditOut_DREN"));

        gridLayout_5->addWidget(lineEditOut_DREN, 7, 1, 1, 1);

        comboBoxInACC = new QComboBox(pageDrainageNetwork);
        comboBoxInACC->setObjectName(QStringLiteral("comboBoxInACC"));

        gridLayout_5->addWidget(comboBoxInACC, 4, 1, 1, 1);

        label_9 = new QLabel(pageDrainageNetwork);
        label_9->setObjectName(QStringLiteral("label_9"));

        gridLayout_5->addWidget(label_9, 7, 0, 1, 1);

        label_8 = new QLabel(pageDrainageNetwork);
        label_8->setObjectName(QStringLiteral("label_8"));

        gridLayout_5->addWidget(label_8, 4, 0, 1, 1);

        label_34 = new QLabel(pageDrainageNetwork);
        label_34->setObjectName(QStringLiteral("label_34"));
        label_34->setFont(font2);

        gridLayout_5->addWidget(label_34, 6, 0, 1, 1);

        label_33 = new QLabel(pageDrainageNetwork);
        label_33->setObjectName(QStringLiteral("label_33"));
        label_33->setFont(font2);

        gridLayout_5->addWidget(label_33, 0, 0, 1, 1);

        line_6 = new QFrame(pageDrainageNetwork);
        line_6->setObjectName(QStringLiteral("line_6"));
        line_6->setFrameShape(QFrame::HLine);
        line_6->setFrameShadow(QFrame::Sunken);

        gridLayout_5->addWidget(line_6, 8, 0, 1, 3);

        verticalSpacer_10 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_5->addItem(verticalSpacer_10, 13, 0, 1, 1);

        line_5 = new QFrame(pageDrainageNetwork);
        line_5->setObjectName(QStringLiteral("line_5"));
        line_5->setFrameShape(QFrame::HLine);
        line_5->setFrameShadow(QFrame::Sunken);

        gridLayout_5->addWidget(line_5, 5, 0, 1, 3);

        label_35 = new QLabel(pageDrainageNetwork);
        label_35->setObjectName(QStringLiteral("label_35"));
        label_35->setFont(font2);

        gridLayout_5->addWidget(label_35, 9, 0, 1, 1);

        label_36 = new QLabel(pageDrainageNetwork);
        label_36->setObjectName(QStringLiteral("label_36"));

        gridLayout_5->addWidget(label_36, 10, 2, 1, 1);

        stackedWidgetRoutines->addWidget(pageDrainageNetwork);
        pageHAND = new QWidget();
        pageHAND->setObjectName(QStringLiteral("pageHAND"));
        gridLayout_6 = new QGridLayout(pageHAND);
        gridLayout_6->setSpacing(6);
        gridLayout_6->setContentsMargins(11, 11, 11, 11);
        gridLayout_6->setObjectName(QStringLiteral("gridLayout_6"));
        comboBoxInDREN = new QComboBox(pageHAND);
        comboBoxInDREN->setObjectName(QStringLiteral("comboBoxInDREN"));

        gridLayout_6->addWidget(comboBoxInDREN, 3, 1, 1, 1);

        label_14 = new QLabel(pageHAND);
        label_14->setObjectName(QStringLiteral("label_14"));

        gridLayout_6->addWidget(label_14, 6, 0, 1, 1);

        label_11 = new QLabel(pageHAND);
        label_11->setObjectName(QStringLiteral("label_11"));

        gridLayout_6->addWidget(label_11, 1, 0, 1, 1);

        comboBoxInLDD_3 = new QComboBox(pageHAND);
        comboBoxInLDD_3->setObjectName(QStringLiteral("comboBoxInLDD_3"));

        gridLayout_6->addWidget(comboBoxInLDD_3, 2, 1, 1, 1);

        label_13 = new QLabel(pageHAND);
        label_13->setObjectName(QStringLiteral("label_13"));

        gridLayout_6->addWidget(label_13, 3, 0, 1, 1);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_6->addItem(verticalSpacer_3, 7, 1, 1, 1);

        lineEditOut_HAND = new QLineEdit(pageHAND);
        lineEditOut_HAND->setObjectName(QStringLiteral("lineEditOut_HAND"));

        gridLayout_6->addWidget(lineEditOut_HAND, 6, 1, 1, 1);

        comboBoxInDEM_2 = new QComboBox(pageHAND);
        comboBoxInDEM_2->setObjectName(QStringLiteral("comboBoxInDEM_2"));

        gridLayout_6->addWidget(comboBoxInDEM_2, 1, 1, 1, 1);

        label_12 = new QLabel(pageHAND);
        label_12->setObjectName(QStringLiteral("label_12"));

        gridLayout_6->addWidget(label_12, 2, 0, 1, 1);

        pushButtonSet_HAND = new QPushButton(pageHAND);
        pushButtonSet_HAND->setObjectName(QStringLiteral("pushButtonSet_HAND"));

        gridLayout_6->addWidget(pushButtonSet_HAND, 6, 2, 1, 1);

        label_31 = new QLabel(pageHAND);
        label_31->setObjectName(QStringLiteral("label_31"));
        label_31->setFont(font2);

        gridLayout_6->addWidget(label_31, 0, 0, 1, 1);

        line_4 = new QFrame(pageHAND);
        line_4->setObjectName(QStringLiteral("line_4"));
        line_4->setFrameShape(QFrame::HLine);
        line_4->setFrameShadow(QFrame::Sunken);

        gridLayout_6->addWidget(line_4, 4, 0, 1, 3);

        label_32 = new QLabel(pageHAND);
        label_32->setObjectName(QStringLiteral("label_32"));
        label_32->setFont(font2);

        gridLayout_6->addWidget(label_32, 5, 0, 1, 1);

        stackedWidgetRoutines->addWidget(pageHAND);
        pageSlopePercentage = new QWidget();
        pageSlopePercentage->setObjectName(QStringLiteral("pageSlopePercentage"));
        gridLayout_7 = new QGridLayout(pageSlopePercentage);
        gridLayout_7->setSpacing(6);
        gridLayout_7->setContentsMargins(11, 11, 11, 11);
        gridLayout_7->setObjectName(QStringLiteral("gridLayout_7"));
        label_16 = new QLabel(pageSlopePercentage);
        label_16->setObjectName(QStringLiteral("label_16"));

        gridLayout_7->addWidget(label_16, 4, 0, 1, 1);

        label_15 = new QLabel(pageSlopePercentage);
        label_15->setObjectName(QStringLiteral("label_15"));

        gridLayout_7->addWidget(label_15, 1, 0, 1, 1);

        lineEditOut_SLOPE = new QLineEdit(pageSlopePercentage);
        lineEditOut_SLOPE->setObjectName(QStringLiteral("lineEditOut_SLOPE"));

        gridLayout_7->addWidget(lineEditOut_SLOPE, 4, 1, 1, 1);

        verticalSpacer_4 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_7->addItem(verticalSpacer_4, 8, 1, 1, 1);

        comboBoxInDEM_3 = new QComboBox(pageSlopePercentage);
        comboBoxInDEM_3->setObjectName(QStringLiteral("comboBoxInDEM_3"));

        gridLayout_7->addWidget(comboBoxInDEM_3, 1, 1, 1, 1);

        checkBoxSlopePercentage = new QCheckBox(pageSlopePercentage);
        checkBoxSlopePercentage->setObjectName(QStringLiteral("checkBoxSlopePercentage"));
        checkBoxSlopePercentage->setChecked(true);

        gridLayout_7->addWidget(checkBoxSlopePercentage, 6, 0, 1, 3);

        pushButtonSet_DEM_2 = new QPushButton(pageSlopePercentage);
        pushButtonSet_DEM_2->setObjectName(QStringLiteral("pushButtonSet_DEM_2"));

        gridLayout_7->addWidget(pushButtonSet_DEM_2, 4, 2, 1, 1);

        line_14 = new QFrame(pageSlopePercentage);
        line_14->setObjectName(QStringLiteral("line_14"));
        line_14->setFrameShape(QFrame::HLine);
        line_14->setFrameShadow(QFrame::Sunken);

        gridLayout_7->addWidget(line_14, 2, 0, 1, 3);

        label_49 = new QLabel(pageSlopePercentage);
        label_49->setObjectName(QStringLiteral("label_49"));
        label_49->setFont(font2);

        gridLayout_7->addWidget(label_49, 0, 0, 1, 1);

        line_15 = new QFrame(pageSlopePercentage);
        line_15->setObjectName(QStringLiteral("line_15"));
        line_15->setFrameShape(QFrame::HLine);
        line_15->setFrameShadow(QFrame::Sunken);

        gridLayout_7->addWidget(line_15, 5, 0, 1, 3);

        label_50 = new QLabel(pageSlopePercentage);
        label_50->setObjectName(QStringLiteral("label_50"));
        label_50->setFont(font2);

        gridLayout_7->addWidget(label_50, 3, 0, 1, 1);

        stackedWidgetRoutines->addWidget(pageSlopePercentage);
        pageClassification = new QWidget();
        pageClassification->setObjectName(QStringLiteral("pageClassification"));
        gridLayout_8 = new QGridLayout(pageClassification);
        gridLayout_8->setSpacing(6);
        gridLayout_8->setContentsMargins(11, 11, 11, 11);
        gridLayout_8->setObjectName(QStringLiteral("gridLayout_8"));
        label_17 = new QLabel(pageClassification);
        label_17->setObjectName(QStringLiteral("label_17"));

        gridLayout_8->addWidget(label_17, 3, 0, 1, 2);

        pushButtonSet_CLASS = new QPushButton(pageClassification);
        pushButtonSet_CLASS->setObjectName(QStringLiteral("pushButtonSet_CLASS"));

        gridLayout_8->addWidget(pushButtonSet_CLASS, 3, 3, 1, 1);

        lineEditOut_CLASS = new QLineEdit(pageClassification);
        lineEditOut_CLASS->setObjectName(QStringLiteral("lineEditOut_CLASS"));

        gridLayout_8->addWidget(lineEditOut_CLASS, 3, 2, 1, 1);

        verticalSpacer_5 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_8->addItem(verticalSpacer_5, 4, 2, 1, 1);

        frameScript = new QFrame(pageClassification);
        frameScript->setObjectName(QStringLiteral("frameScript"));
        frameScript->setMinimumSize(QSize(0, 100));
        frameScript->setFrameShape(QFrame::NoFrame);
        frameScript->setFrameShadow(QFrame::Plain);
        gridLayout_9 = new QGridLayout(frameScript);
        gridLayout_9->setSpacing(6);
        gridLayout_9->setContentsMargins(11, 11, 11, 11);
        gridLayout_9->setObjectName(QStringLiteral("gridLayout_9"));
        gridLayout_9->setContentsMargins(0, 0, 0, 0);
        pushButtonDelColor = new QPushButton(frameScript);
        pushButtonDelColor->setObjectName(QStringLiteral("pushButtonDelColor"));

        gridLayout_9->addWidget(pushButtonDelColor, 5, 1, 1, 1);

        pushButtonAdd = new QPushButton(frameScript);
        pushButtonAdd->setObjectName(QStringLiteral("pushButtonAdd"));

        gridLayout_9->addWidget(pushButtonAdd, 0, 1, 1, 1);

        pushButtonRemove = new QPushButton(frameScript);
        pushButtonRemove->setObjectName(QStringLiteral("pushButtonRemove"));

        gridLayout_9->addWidget(pushButtonRemove, 1, 1, 1, 1);

        verticalSpacer_6 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_9->addItem(verticalSpacer_6, 6, 1, 1, 1);

        tableWidgetScript = new QTableWidget(frameScript);
        tableWidgetScript->setObjectName(QStringLiteral("tableWidgetScript"));

        gridLayout_9->addWidget(tableWidgetScript, 0, 0, 7, 1);

        pushButtonSaveColor = new QPushButton(frameScript);
        pushButtonSaveColor->setObjectName(QStringLiteral("pushButtonSaveColor"));

        gridLayout_9->addWidget(pushButtonSaveColor, 4, 1, 1, 1);

        line_2 = new QFrame(frameScript);
        line_2->setObjectName(QStringLiteral("line_2"));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);

        gridLayout_9->addWidget(line_2, 2, 1, 1, 1);

        comboBoxColor = new QComboBox(frameScript);
        comboBoxColor->setObjectName(QStringLiteral("comboBoxColor"));
        comboBoxColor->setEditable(true);

        gridLayout_9->addWidget(comboBoxColor, 3, 1, 1, 1);


        gridLayout_8->addWidget(frameScript, 0, 0, 1, 4);

        line_13 = new QFrame(pageClassification);
        line_13->setObjectName(QStringLiteral("line_13"));
        line_13->setFrameShape(QFrame::HLine);
        line_13->setFrameShadow(QFrame::Sunken);

        gridLayout_8->addWidget(line_13, 2, 0, 1, 4);

        stackedWidgetRoutines->addWidget(pageClassification);
        pageHANDContour = new QWidget();
        pageHANDContour->setObjectName(QStringLiteral("pageHANDContour"));
        gridLayout_11 = new QGridLayout(pageHANDContour);
        gridLayout_11->setSpacing(6);
        gridLayout_11->setContentsMargins(11, 11, 11, 11);
        gridLayout_11->setObjectName(QStringLiteral("gridLayout_11"));
        comboBoxInHAND = new QComboBox(pageHANDContour);
        comboBoxInHAND->setObjectName(QStringLiteral("comboBoxInHAND"));
        comboBoxInHAND->setEditable(false);

        gridLayout_11->addWidget(comboBoxInHAND, 1, 1, 1, 1);

        label_18 = new QLabel(pageHANDContour);
        label_18->setObjectName(QStringLiteral("label_18"));
        sizePolicy.setHeightForWidth(label_18->sizePolicy().hasHeightForWidth());
        label_18->setSizePolicy(sizePolicy);

        gridLayout_11->addWidget(label_18, 1, 0, 1, 1);

        lineEditOut_HANDC = new QLineEdit(pageHANDContour);
        lineEditOut_HANDC->setObjectName(QStringLiteral("lineEditOut_HANDC"));

        gridLayout_11->addWidget(lineEditOut_HANDC, 4, 1, 1, 1);

        label_21 = new QLabel(pageHANDContour);
        label_21->setObjectName(QStringLiteral("label_21"));

        gridLayout_11->addWidget(label_21, 4, 0, 1, 1);

        pushButtonSet_HANDC = new QPushButton(pageHANDContour);
        pushButtonSet_HANDC->setObjectName(QStringLiteral("pushButtonSet_HANDC"));

        gridLayout_11->addWidget(pushButtonSet_HANDC, 4, 2, 1, 1);

        verticalSpacer_7 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_11->addItem(verticalSpacer_7, 9, 1, 1, 1);

        label_25 = new QLabel(pageHANDContour);
        label_25->setObjectName(QStringLiteral("label_25"));

        gridLayout_11->addWidget(label_25, 7, 0, 1, 1);

        spinBoxWidth = new QSpinBox(pageHANDContour);
        spinBoxWidth->setObjectName(QStringLiteral("spinBoxWidth"));
        spinBoxWidth->setMinimum(1);

        gridLayout_11->addWidget(spinBoxWidth, 7, 1, 1, 1);

        line_12 = new QFrame(pageHANDContour);
        line_12->setObjectName(QStringLiteral("line_12"));
        line_12->setFrameShape(QFrame::HLine);
        line_12->setFrameShadow(QFrame::Sunken);

        gridLayout_11->addWidget(line_12, 5, 0, 1, 3);

        label_47 = new QLabel(pageHANDContour);
        label_47->setObjectName(QStringLiteral("label_47"));
        label_47->setFont(font2);

        gridLayout_11->addWidget(label_47, 3, 0, 1, 1);

        line_11 = new QFrame(pageHANDContour);
        line_11->setObjectName(QStringLiteral("line_11"));
        line_11->setFrameShape(QFrame::HLine);
        line_11->setFrameShadow(QFrame::Sunken);

        gridLayout_11->addWidget(line_11, 2, 0, 1, 3);

        label_46 = new QLabel(pageHANDContour);
        label_46->setObjectName(QStringLiteral("label_46"));
        label_46->setFont(font2);

        gridLayout_11->addWidget(label_46, 0, 0, 1, 1);

        label_48 = new QLabel(pageHANDContour);
        label_48->setObjectName(QStringLiteral("label_48"));
        label_48->setFont(font2);

        gridLayout_11->addWidget(label_48, 6, 0, 1, 1);

        label_53 = new QLabel(pageHANDContour);
        label_53->setObjectName(QStringLiteral("label_53"));

        gridLayout_11->addWidget(label_53, 8, 0, 1, 1);

        spinBoxOffset = new QSpinBox(pageHANDContour);
        spinBoxOffset->setObjectName(QStringLiteral("spinBoxOffset"));
        spinBoxOffset->setMaximum(150);

        gridLayout_11->addWidget(spinBoxOffset, 8, 1, 1, 1);

        stackedWidgetRoutines->addWidget(pageHANDContour);
        pageHANDChannel = new QWidget();
        pageHANDChannel->setObjectName(QStringLiteral("pageHANDChannel"));
        gridLayout_12 = new QGridLayout(pageHANDChannel);
        gridLayout_12->setSpacing(6);
        gridLayout_12->setContentsMargins(11, 11, 11, 11);
        gridLayout_12->setObjectName(QStringLiteral("gridLayout_12"));
        label_24 = new QLabel(pageHANDChannel);
        label_24->setObjectName(QStringLiteral("label_24"));

        gridLayout_12->addWidget(label_24, 5, 0, 1, 1);

        label_45 = new QLabel(pageHANDChannel);
        label_45->setObjectName(QStringLiteral("label_45"));
        label_45->setFont(font2);

        gridLayout_12->addWidget(label_45, 7, 0, 1, 1);

        label_20 = new QLabel(pageHANDChannel);
        label_20->setObjectName(QStringLiteral("label_20"));

        gridLayout_12->addWidget(label_20, 4, 0, 1, 1);

        pushButtonSet_HCHAN = new QPushButton(pageHANDChannel);
        pushButtonSet_HCHAN->setObjectName(QStringLiteral("pushButtonSet_HCHAN"));

        gridLayout_12->addWidget(pushButtonSet_HCHAN, 8, 2, 1, 1);

        label_23 = new QLabel(pageHANDChannel);
        label_23->setObjectName(QStringLiteral("label_23"));

        gridLayout_12->addWidget(label_23, 8, 0, 1, 1);

        comboBoxInDEM_4 = new QComboBox(pageHANDChannel);
        comboBoxInDEM_4->setObjectName(QStringLiteral("comboBoxInDEM_4"));

        gridLayout_12->addWidget(comboBoxInDEM_4, 1, 1, 1, 1);

        verticalSpacer_8 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_12->addItem(verticalSpacer_8, 9, 1, 1, 1);

        label_22 = new QLabel(pageHANDChannel);
        label_22->setObjectName(QStringLiteral("label_22"));

        gridLayout_12->addWidget(label_22, 1, 0, 1, 1);

        lineEditOut_HCHAN = new QLineEdit(pageHANDChannel);
        lineEditOut_HCHAN->setObjectName(QStringLiteral("lineEditOut_HCHAN"));

        gridLayout_12->addWidget(lineEditOut_HCHAN, 8, 1, 1, 1);

        comboBoxInDREN_2 = new QComboBox(pageHANDChannel);
        comboBoxInDREN_2->setObjectName(QStringLiteral("comboBoxInDREN_2"));

        gridLayout_12->addWidget(comboBoxInDREN_2, 5, 1, 1, 1);

        comboBoxInLDD_4 = new QComboBox(pageHANDChannel);
        comboBoxInLDD_4->setObjectName(QStringLiteral("comboBoxInLDD_4"));

        gridLayout_12->addWidget(comboBoxInLDD_4, 4, 1, 1, 1);

        line_10 = new QFrame(pageHANDChannel);
        line_10->setObjectName(QStringLiteral("line_10"));
        line_10->setFrameShape(QFrame::HLine);
        line_10->setFrameShadow(QFrame::Sunken);

        gridLayout_12->addWidget(line_10, 6, 0, 1, 3);

        label_44 = new QLabel(pageHANDChannel);
        label_44->setObjectName(QStringLiteral("label_44"));
        label_44->setFont(font2);

        gridLayout_12->addWidget(label_44, 0, 0, 1, 1);

        stackedWidgetRoutines->addWidget(pageHANDChannel);
        pageChannelMask = new QWidget();
        pageChannelMask->setObjectName(QStringLiteral("pageChannelMask"));
        gridLayout_13 = new QGridLayout(pageChannelMask);
        gridLayout_13->setSpacing(6);
        gridLayout_13->setContentsMargins(11, 11, 11, 11);
        gridLayout_13->setObjectName(QStringLiteral("gridLayout_13"));
        pushButtonSet_CMASK = new QPushButton(pageChannelMask);
        pushButtonSet_CMASK->setObjectName(QStringLiteral("pushButtonSet_CMASK"));

        gridLayout_13->addWidget(pushButtonSet_CMASK, 12, 2, 1, 1);

        line_9 = new QFrame(pageChannelMask);
        line_9->setObjectName(QStringLiteral("line_9"));
        line_9->setFrameShape(QFrame::HLine);
        line_9->setFrameShadow(QFrame::Sunken);

        gridLayout_13->addWidget(line_9, 10, 0, 1, 3);

        label_43 = new QLabel(pageChannelMask);
        label_43->setObjectName(QStringLiteral("label_43"));
        label_43->setFont(font2);

        gridLayout_13->addWidget(label_43, 15, 0, 1, 1);

        spinBoxFlood = new QSpinBox(pageChannelMask);
        spinBoxFlood->setObjectName(QStringLiteral("spinBoxFlood"));
        spinBoxFlood->setMaximum(5000);
        spinBoxFlood->setValue(5);

        gridLayout_13->addWidget(spinBoxFlood, 16, 1, 1, 1);

        lineEditLon = new QLineEdit(pageChannelMask);
        lineEditLon->setObjectName(QStringLiteral("lineEditLon"));

        gridLayout_13->addWidget(lineEditLon, 20, 1, 1, 1);

        comboBoxInLDD_5 = new QComboBox(pageChannelMask);
        comboBoxInLDD_5->setObjectName(QStringLiteral("comboBoxInLDD_5"));

        gridLayout_13->addWidget(comboBoxInLDD_5, 6, 1, 1, 1);

        label_29 = new QLabel(pageChannelMask);
        label_29->setObjectName(QStringLiteral("label_29"));

        gridLayout_13->addWidget(label_29, 19, 0, 1, 1);

        comboBoxInDREN_3 = new QComboBox(pageChannelMask);
        comboBoxInDREN_3->setObjectName(QStringLiteral("comboBoxInDREN_3"));

        gridLayout_13->addWidget(comboBoxInDREN_3, 8, 1, 1, 1);

        label_28 = new QLabel(pageChannelMask);
        label_28->setObjectName(QStringLiteral("label_28"));

        gridLayout_13->addWidget(label_28, 16, 0, 1, 1);

        label_54 = new QLabel(pageChannelMask);
        label_54->setObjectName(QStringLiteral("label_54"));

        gridLayout_13->addWidget(label_54, 13, 0, 1, 1);

        label_42 = new QLabel(pageChannelMask);
        label_42->setObjectName(QStringLiteral("label_42"));
        label_42->setFont(font2);

        gridLayout_13->addWidget(label_42, 11, 0, 1, 1);

        lineEditOut_CMASK2 = new QLineEdit(pageChannelMask);
        lineEditOut_CMASK2->setObjectName(QStringLiteral("lineEditOut_CMASK2"));

        gridLayout_13->addWidget(lineEditOut_CMASK2, 13, 1, 1, 1);

        lineEditOut_CMASK = new QLineEdit(pageChannelMask);
        lineEditOut_CMASK->setObjectName(QStringLiteral("lineEditOut_CMASK"));

        gridLayout_13->addWidget(lineEditOut_CMASK, 12, 1, 1, 1);

        line_3 = new QFrame(pageChannelMask);
        line_3->setObjectName(QStringLiteral("line_3"));
        line_3->setFrameShape(QFrame::HLine);
        line_3->setFrameShadow(QFrame::Sunken);

        gridLayout_13->addWidget(line_3, 14, 0, 1, 3);

        label_30 = new QLabel(pageChannelMask);
        label_30->setObjectName(QStringLiteral("label_30"));

        gridLayout_13->addWidget(label_30, 20, 0, 1, 1);

        lineEditLat = new QLineEdit(pageChannelMask);
        lineEditLat->setObjectName(QStringLiteral("lineEditLat"));

        gridLayout_13->addWidget(lineEditLat, 19, 1, 1, 1);

        pushButtonSet_CMASK2 = new QPushButton(pageChannelMask);
        pushButtonSet_CMASK2->setObjectName(QStringLiteral("pushButtonSet_CMASK2"));

        gridLayout_13->addWidget(pushButtonSet_CMASK2, 13, 2, 1, 1);

        verticalSpacer_9 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_13->addItem(verticalSpacer_9, 21, 1, 1, 1);

        label_27 = new QLabel(pageChannelMask);
        label_27->setObjectName(QStringLiteral("label_27"));

        gridLayout_13->addWidget(label_27, 12, 0, 1, 1);

        comboBoxInDEM_5 = new QComboBox(pageChannelMask);
        comboBoxInDEM_5->setObjectName(QStringLiteral("comboBoxInDEM_5"));

        gridLayout_13->addWidget(comboBoxInDEM_5, 1, 1, 1, 1);

        label_41 = new QLabel(pageChannelMask);
        label_41->setObjectName(QStringLiteral("label_41"));
        label_41->setFont(font2);

        gridLayout_13->addWidget(label_41, 0, 0, 1, 1);

        label_52 = new QLabel(pageChannelMask);
        label_52->setObjectName(QStringLiteral("label_52"));

        gridLayout_13->addWidget(label_52, 8, 0, 1, 1);

        label_51 = new QLabel(pageChannelMask);
        label_51->setObjectName(QStringLiteral("label_51"));

        gridLayout_13->addWidget(label_51, 6, 0, 1, 1);

        label_26 = new QLabel(pageChannelMask);
        label_26->setObjectName(QStringLiteral("label_26"));

        gridLayout_13->addWidget(label_26, 1, 0, 1, 1);

        label_55 = new QLabel(pageChannelMask);
        label_55->setObjectName(QStringLiteral("label_55"));

        gridLayout_13->addWidget(label_55, 7, 0, 1, 1);

        comboBoxInACC_2 = new QComboBox(pageChannelMask);
        comboBoxInACC_2->setObjectName(QStringLiteral("comboBoxInACC_2"));

        gridLayout_13->addWidget(comboBoxInACC_2, 7, 1, 1, 1);

        stackedWidgetRoutines->addWidget(pageChannelMask);

        gridLayout->addWidget(stackedWidgetRoutines, 1, 0, 1, 3);

        dockWidgetAnalysis->setWidget(dockWidgetContentsAnalysis);
        HandModel->addDockWidget(static_cast<Qt::DockWidgetArea>(2), dockWidgetAnalysis);

        menuBar->addAction(menuFile->menuAction());
        menuBar->addAction(menuView->menuAction());
        menuBar->addAction(menuHelp->menuAction());
        menuFile->addAction(actionOpen);
        menuFile->addAction(actionWizard);
        menuFile->addSeparator();
        menuFile->addAction(actionImport);
        menuFile->addAction(actionExport);
        menuFile->addSeparator();
        menuFile->addAction(actionQuit);
        menuView->addAction(actionBrowser);
        menuView->addAction(actionLayers);
        menuView->addAction(actionRaster_Data);
        menuView->addSeparator();
        menuView->addAction(actionRaster_Analysis_2);
        menuHelp->addAction(actionAbout_HAND);
        menuHelp->addSeparator();
        menuHelp->addAction(actionAbout_Qt);
        mainToolBar->addAction(actionSet_Workspace_Directory);
        mainToolBar->addSeparator();
        mainToolBar->addAction(actionLoad_Project);
        mainToolBar->addAction(actionSave_Project);
        mainToolBar->addSeparator();
        mainToolBar->addAction(actionWizardMode);
        mainToolBar->addAction(actionRaster_Analysis);
        mainToolBar->addSeparator();
        mainToolBar->addAction(actionDEMC);
        mainToolBar->addAction(actionACC);
        mainToolBar->addAction(actionDrainage);
        mainToolBar->addAction(actionHAND);
        mainToolBar->addAction(actionSlope);
        mainToolBar->addAction(actionColor);
        mainToolBar->addAction(actionHAND_Contour);
        mainToolBar->addAction(actionHCHAN);
        mainToolBar->addAction(actionCMASK);

        retranslateUi(HandModel);

        stackedWidgetRoutines->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(HandModel);
    } // setupUi

    void retranslateUi(QMainWindow *HandModel)
    {
        HandModel->setWindowTitle(QApplication::translate("HandModel", "HandModel", Q_NULLPTR));
        actionSave_Project->setText(QApplication::translate("HandModel", "Save Project", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        actionSave_Project->setToolTip(QApplication::translate("HandModel", "Save Project", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        actionSave_Project->setShortcut(QApplication::translate("HandModel", "Ctrl+S", Q_NULLPTR));
        actionLoad_Project->setText(QApplication::translate("HandModel", "Load Project", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        actionLoad_Project->setToolTip(QApplication::translate("HandModel", "Load Project", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        actionLoad_Project->setShortcut(QApplication::translate("HandModel", "Ctrl+O", Q_NULLPTR));
        actionSet_Workspace_Directory->setText(QApplication::translate("HandModel", "Set Workspace Directory", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        actionSet_Workspace_Directory->setToolTip(QApplication::translate("HandModel", "Set Workspace Directory", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        actionSet_Workspace_Directory->setShortcut(QApplication::translate("HandModel", "Ctrl+D", Q_NULLPTR));
        actionOpen->setText(QApplication::translate("HandModel", "&Open File/Project...", Q_NULLPTR));
        actionExport->setText(QApplication::translate("HandModel", "&Export", Q_NULLPTR));
        actionQuit->setText(QApplication::translate("HandModel", "&Quit", Q_NULLPTR));
        actionImport->setText(QApplication::translate("HandModel", "&Import", Q_NULLPTR));
        actionWizardMode->setText(QApplication::translate("HandModel", "WizardMode", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        actionWizardMode->setToolTip(QApplication::translate("HandModel", "Dem2HAND", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        actionBrowser->setText(QApplication::translate("HandModel", "&Browser", Q_NULLPTR));
        actionLayers->setText(QApplication::translate("HandModel", "&Layers", Q_NULLPTR));
        actionRaster_Data->setText(QApplication::translate("HandModel", "Raster &Data", Q_NULLPTR));
        actionRaster_Analysis_2->setText(QApplication::translate("HandModel", "&Image Analysis", Q_NULLPTR));
        actionAbout_Qt->setText(QApplication::translate("HandModel", "About &Qt", Q_NULLPTR));
        actionAbout_HAND->setText(QApplication::translate("HandModel", "About &HAND", Q_NULLPTR));
        actionWizard->setText(QApplication::translate("HandModel", "DEM2HAND &Wizard...", Q_NULLPTR));
        actionRaster_Analysis->setText(QApplication::translate("HandModel", "Image Analysis", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        actionRaster_Analysis->setToolTip(QApplication::translate("HandModel", "Image Analysis", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        actionHAND_Contour->setText(QApplication::translate("HandModel", "HAND Contour", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        actionHAND_Contour->setToolTip(QApplication::translate("HandModel", "HAND Contour", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        actionSlope->setText(QApplication::translate("HandModel", "Slope", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        actionSlope->setToolTip(QApplication::translate("HandModel", "Slope", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        actionDrainage->setText(QApplication::translate("HandModel", "Drainage", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        actionDrainage->setToolTip(QApplication::translate("HandModel", "Drainage", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        actionACC->setText(QApplication::translate("HandModel", "ACC", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        actionACC->setToolTip(QApplication::translate("HandModel", "ACC", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        actionHAND->setText(QApplication::translate("HandModel", "HAND", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        actionHAND->setToolTip(QApplication::translate("HandModel", "Height Above the Nearest Drainage", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        actionColor->setText(QApplication::translate("HandModel", "Color", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        actionColor->setToolTip(QApplication::translate("HandModel", "Color Classification", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        actionDEMC->setText(QApplication::translate("HandModel", "DEMC", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        actionDEMC->setToolTip(QApplication::translate("HandModel", "Corrected DEM", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        actionCMASK->setText(QApplication::translate("HandModel", "Channel Mask", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        actionCMASK->setToolTip(QApplication::translate("HandModel", "HAND Channel Mask", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        actionHCHAN->setText(QApplication::translate("HandModel", "HCHAN", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        actionHCHAN->setToolTip(QApplication::translate("HandModel", "HAND Channel", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        menuFile->setTitle(QApplication::translate("HandModel", "&File", Q_NULLPTR));
        menuView->setTitle(QApplication::translate("HandModel", "&View", Q_NULLPTR));
        menuHelp->setTitle(QApplication::translate("HandModel", "&Help", Q_NULLPTR));
        dockWidgetBrowser->setWindowTitle(QApplication::translate("HandModel", "File Browser", Q_NULLPTR));
        dockWidgetLayer->setWindowTitle(QApplication::translate("HandModel", "Image Layer", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pbimgUp->setToolTip(QApplication::translate("HandModel", "Raise image one step", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pbimgUp->setText(QString());
#ifndef QT_NO_TOOLTIP
        pbimgDown->setToolTip(QApplication::translate("HandModel", "Lower image one step", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pbimgDown->setText(QString());
#ifndef QT_NO_TOOLTIP
        pbimgRemove->setToolTip(QApplication::translate("HandModel", "Remove image", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pbimgRemove->setText(QString());
#ifndef QT_NO_TOOLTIP
        pbimgFit->setToolTip(QApplication::translate("HandModel", "Fit into view", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_TOOLTIP
        pbimgInfo->setToolTip(QApplication::translate("HandModel", "File info", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        dockWidgetRasterData->setWindowTitle(QApplication::translate("HandModel", "Raster Data", Q_NULLPTR));
        dockWidgetAnalysis->setWindowTitle(QApplication::translate("HandModel", "Image Analysis", Q_NULLPTR));
        pushButtonOk->setText(QApplication::translate("HandModel", "Ok", Q_NULLPTR));
        pushButtonCancel->setText(QApplication::translate("HandModel", "Close", Q_NULLPTR));
        checkBoxLoadOutput->setText(QApplication::translate("HandModel", "Load output file(s) after analysis", Q_NULLPTR));
        pushButtonSet_LDD->setText(QApplication::translate("HandModel", "Select...", Q_NULLPTR));
        label_19->setText(QApplication::translate("HandModel", "Algorithm type", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        radioButtonFill->setToolTip(QApplication::translate("HandModel", "Fast algorithm to be used in large images.", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        radioButtonFill->setText(QApplication::translate("HandModel", "Fill", Q_NULLPTR));
        label_40->setText(QApplication::translate("HandModel", "Outputs", Q_NULLPTR));
        pushButtonSet_DEMC->setText(QApplication::translate("HandModel", "Select...", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        radioButtonBreaching->setToolTip(QApplication::translate("HandModel", "Slower algorithm with a better result. It does not work well with large images.", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        radioButtonBreaching->setText(QApplication::translate("HandModel", "Breaching", Q_NULLPTR));
        label_2->setText(QApplication::translate("HandModel", "DEMC", Q_NULLPTR));
        label_3->setText(QApplication::translate("HandModel", "LDD", Q_NULLPTR));
        label_39->setText(QApplication::translate("HandModel", "Input", Q_NULLPTR));
        label_56->setText(QApplication::translate("HandModel", "DEM", Q_NULLPTR));
        label->setText(QApplication::translate("HandModel", "<html><head/><body><div style=\" font-size:9pt; font-style:italic;\">Fill: Fast algorithm to be used <br/>in large 		 images, but less accuracy.</div></body></html>", Q_NULLPTR));
        label_6->setText(QApplication::translate("HandModel", "ACC", Q_NULLPTR));
        label_5->setText(QApplication::translate("HandModel", "LDD", Q_NULLPTR));
        pushButtonSet_ACC->setText(QApplication::translate("HandModel", "Select...", Q_NULLPTR));
        label_37->setText(QApplication::translate("HandModel", "Input", Q_NULLPTR));
        label_38->setText(QApplication::translate("HandModel", "Output", Q_NULLPTR));
        label_4->setText(QApplication::translate("HandModel", "LDD", Q_NULLPTR));
        pushButtonSet_DREN->setText(QApplication::translate("HandModel", "Select...", Q_NULLPTR));
        label_7->setText(QApplication::translate("HandModel", "DEMC", Q_NULLPTR));
        checkBoxThreshold->setText(QApplication::translate("HandModel", "File threshold sufix", Q_NULLPTR));
        labelThresholdCalc->setText(QString());
        label_10->setText(QApplication::translate("HandModel", "Threshold", Q_NULLPTR));
        label_9->setText(QApplication::translate("HandModel", "DREN", Q_NULLPTR));
        label_8->setText(QApplication::translate("HandModel", "ACC", Q_NULLPTR));
        label_34->setText(QApplication::translate("HandModel", "Output", Q_NULLPTR));
        label_33->setText(QApplication::translate("HandModel", "Inputs", Q_NULLPTR));
        label_35->setText(QApplication::translate("HandModel", "Options", Q_NULLPTR));
        label_36->setText(QApplication::translate("HandModel", "px", Q_NULLPTR));
        label_14->setText(QApplication::translate("HandModel", "HAND", Q_NULLPTR));
        label_11->setText(QApplication::translate("HandModel", "DEM", Q_NULLPTR));
        label_13->setText(QApplication::translate("HandModel", "DREN", Q_NULLPTR));
        label_12->setText(QApplication::translate("HandModel", "LDD", Q_NULLPTR));
        pushButtonSet_HAND->setText(QApplication::translate("HandModel", "Select...", Q_NULLPTR));
        label_31->setText(QApplication::translate("HandModel", "Inputs", Q_NULLPTR));
        label_32->setText(QApplication::translate("HandModel", "Output", Q_NULLPTR));
        label_16->setText(QApplication::translate("HandModel", "Slope", Q_NULLPTR));
        label_15->setText(QApplication::translate("HandModel", "DEM", Q_NULLPTR));
        checkBoxSlopePercentage->setText(QApplication::translate("HandModel", "Slope Percentage (%)", Q_NULLPTR));
        pushButtonSet_DEM_2->setText(QApplication::translate("HandModel", "Select...", Q_NULLPTR));
        label_49->setText(QApplication::translate("HandModel", "Input", Q_NULLPTR));
        label_50->setText(QApplication::translate("HandModel", "Output", Q_NULLPTR));
        label_17->setText(QApplication::translate("HandModel", "Output (Classification)", Q_NULLPTR));
        pushButtonSet_CLASS->setText(QApplication::translate("HandModel", "Select...", Q_NULLPTR));
        pushButtonDelColor->setText(QApplication::translate("HandModel", "Delete", Q_NULLPTR));
        pushButtonAdd->setText(QApplication::translate("HandModel", "Add", Q_NULLPTR));
        pushButtonRemove->setText(QApplication::translate("HandModel", "Remove", Q_NULLPTR));
        pushButtonSaveColor->setText(QApplication::translate("HandModel", "Save", Q_NULLPTR));
        label_18->setText(QApplication::translate("HandModel", "HAND", Q_NULLPTR));
        label_21->setText(QApplication::translate("HandModel", "HANDC", Q_NULLPTR));
        pushButtonSet_HANDC->setText(QApplication::translate("HandModel", "Select...", Q_NULLPTR));
        label_25->setText(QApplication::translate("HandModel", "Interval (m)", Q_NULLPTR));
        label_47->setText(QApplication::translate("HandModel", "Output", Q_NULLPTR));
        label_46->setText(QApplication::translate("HandModel", "Input", Q_NULLPTR));
        label_48->setText(QApplication::translate("HandModel", "Height options", Q_NULLPTR));
        label_53->setText(QApplication::translate("HandModel", "Begins in (m)", Q_NULLPTR));
        label_24->setText(QApplication::translate("HandModel", "DREN", Q_NULLPTR));
        label_45->setText(QApplication::translate("HandModel", "Output", Q_NULLPTR));
        label_20->setText(QApplication::translate("HandModel", "LDD", Q_NULLPTR));
        pushButtonSet_HCHAN->setText(QApplication::translate("HandModel", "Select...", Q_NULLPTR));
        label_23->setText(QApplication::translate("HandModel", "HCHAN", Q_NULLPTR));
        label_22->setText(QApplication::translate("HandModel", "DEM", Q_NULLPTR));
        label_44->setText(QApplication::translate("HandModel", "Inputs", Q_NULLPTR));
        pushButtonSet_CMASK->setText(QApplication::translate("HandModel", "Select...", Q_NULLPTR));
        label_43->setText(QApplication::translate("HandModel", "Options", Q_NULLPTR));
        label_29->setText(QApplication::translate("HandModel", "Latitude", Q_NULLPTR));
        label_28->setText(QApplication::translate("HandModel", "Level (m)", Q_NULLPTR));
        label_54->setText(QApplication::translate("HandModel", "CMASK", Q_NULLPTR));
        label_42->setText(QApplication::translate("HandModel", "Outputs", Q_NULLPTR));
        label_30->setText(QApplication::translate("HandModel", "Longitude", Q_NULLPTR));
        pushButtonSet_CMASK2->setText(QApplication::translate("HandModel", "Select...", Q_NULLPTR));
        label_27->setText(QApplication::translate("HandModel", "Pixmap", Q_NULLPTR));
        label_41->setText(QApplication::translate("HandModel", "Inputs", Q_NULLPTR));
        label_52->setText(QApplication::translate("HandModel", "DREN", Q_NULLPTR));
        label_51->setText(QApplication::translate("HandModel", "LDD", Q_NULLPTR));
        label_26->setText(QApplication::translate("HandModel", "DEM", Q_NULLPTR));
        label_55->setText(QApplication::translate("HandModel", "ACC", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class HandModel: public Ui_HandModel {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HANDMODEL_H
