/********************************************************************************
** Form generated from reading UI file 'Dem2handdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DEM2HANDDIALOG_H
#define UI_DEM2HANDDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>

QT_BEGIN_NAMESPACE

class Ui_Dem2HandDialog
{
public:
    QGridLayout *gridLayout;
    QPushButton *pushButton_Out_DEM;
    QLabel *label_2;
    QLabel *label_5;
    QLineEdit *lineEdit_ACC;
    QLabel *label_3;
    QLabel *label_8;
    QLineEdit *lineEdit_DREN;
    QFrame *line_6;
    QFrame *line_5;
    QLineEdit *lineEdit_DEM;
    QLabel *label_4;
    QPushButton *pushButton_Out_LDD;
    QFrame *line;
    QPushButton *pushButton_Out_ACC;
    QLineEdit *lineEdit_DEMC;
    QRadioButton *radioButtonFill;
    QProgressBar *progressBar;
    QLabel *labelDRENValue;
    QLabel *label_6;
    QRadioButton *radioButtonBreaching;
    QLabel *label;
    QLineEdit *lineEdit_LDD;
    QFrame *line_3;
    QSpinBox *spinBoxThreshold;
    QLineEdit *lineEdit_HANDC;
    QPushButton *pushButton_Out_HANDC;
    QLabel *label_7;
    QLabel *labelEventName;
    QCheckBox *checkBoxOnlyHAND;
    QGroupBox *groupBox;
    QHBoxLayout *horizontalLayout;
    QPushButton *pushButtonFechar;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButtonCancel;
    QPushButton *pushButtonOK;
    QFrame *line_2;
    QPushButton *pushButton_In_DEM;
    QPushButton *pushButton_Out_DREN;
    QLabel *label_9;
    QLineEdit *lineEdit_HAND;
    QPushButton *pushButton_Out_HAND;

    void setupUi(QDialog *Dem2HandDialog)
    {
        if (Dem2HandDialog->objectName().isEmpty())
            Dem2HandDialog->setObjectName(QStringLiteral("Dem2HandDialog"));
        Dem2HandDialog->resize(400, 630);
        gridLayout = new QGridLayout(Dem2HandDialog);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        pushButton_Out_DEM = new QPushButton(Dem2HandDialog);
        pushButton_Out_DEM->setObjectName(QStringLiteral("pushButton_Out_DEM"));

        gridLayout->addWidget(pushButton_Out_DEM, 7, 3, 1, 1);

        label_2 = new QLabel(Dem2HandDialog);
        label_2->setObjectName(QStringLiteral("label_2"));

        gridLayout->addWidget(label_2, 5, 0, 1, 1);

        label_5 = new QLabel(Dem2HandDialog);
        label_5->setObjectName(QStringLiteral("label_5"));

        gridLayout->addWidget(label_5, 19, 0, 1, 1);

        lineEdit_ACC = new QLineEdit(Dem2HandDialog);
        lineEdit_ACC->setObjectName(QStringLiteral("lineEdit_ACC"));

        gridLayout->addWidget(lineEdit_ACC, 9, 2, 1, 1);

        label_3 = new QLabel(Dem2HandDialog);
        label_3->setObjectName(QStringLiteral("label_3"));

        gridLayout->addWidget(label_3, 9, 0, 1, 1);

        label_8 = new QLabel(Dem2HandDialog);
        label_8->setObjectName(QStringLiteral("label_8"));

        gridLayout->addWidget(label_8, 7, 0, 1, 1);

        lineEdit_DREN = new QLineEdit(Dem2HandDialog);
        lineEdit_DREN->setObjectName(QStringLiteral("lineEdit_DREN"));

        gridLayout->addWidget(lineEdit_DREN, 11, 2, 1, 1);

        line_6 = new QFrame(Dem2HandDialog);
        line_6->setObjectName(QStringLiteral("line_6"));
        line_6->setMinimumSize(QSize(0, 10));
        line_6->setFrameShape(QFrame::HLine);
        line_6->setFrameShadow(QFrame::Sunken);

        gridLayout->addWidget(line_6, 17, 0, 1, 4);

        line_5 = new QFrame(Dem2HandDialog);
        line_5->setObjectName(QStringLiteral("line_5"));
        line_5->setMinimumSize(QSize(0, 10));
        line_5->setFrameShape(QFrame::HLine);
        line_5->setFrameShadow(QFrame::Sunken);

        gridLayout->addWidget(line_5, 14, 1, 1, 1);

        lineEdit_DEM = new QLineEdit(Dem2HandDialog);
        lineEdit_DEM->setObjectName(QStringLiteral("lineEdit_DEM"));

        gridLayout->addWidget(lineEdit_DEM, 0, 2, 1, 1);

        label_4 = new QLabel(Dem2HandDialog);
        label_4->setObjectName(QStringLiteral("label_4"));

        gridLayout->addWidget(label_4, 11, 0, 1, 2);

        pushButton_Out_LDD = new QPushButton(Dem2HandDialog);
        pushButton_Out_LDD->setObjectName(QStringLiteral("pushButton_Out_LDD"));

        gridLayout->addWidget(pushButton_Out_LDD, 5, 3, 1, 1);

        line = new QFrame(Dem2HandDialog);
        line->setObjectName(QStringLiteral("line"));
        line->setMinimumSize(QSize(0, 10));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        gridLayout->addWidget(line, 1, 0, 1, 4);

        pushButton_Out_ACC = new QPushButton(Dem2HandDialog);
        pushButton_Out_ACC->setObjectName(QStringLiteral("pushButton_Out_ACC"));

        gridLayout->addWidget(pushButton_Out_ACC, 9, 3, 1, 1);

        lineEdit_DEMC = new QLineEdit(Dem2HandDialog);
        lineEdit_DEMC->setObjectName(QStringLiteral("lineEdit_DEMC"));

        gridLayout->addWidget(lineEdit_DEMC, 7, 2, 1, 1);

        radioButtonFill = new QRadioButton(Dem2HandDialog);
        radioButtonFill->setObjectName(QStringLiteral("radioButtonFill"));
        radioButtonFill->setChecked(true);

        gridLayout->addWidget(radioButtonFill, 2, 2, 1, 1);

        progressBar = new QProgressBar(Dem2HandDialog);
        progressBar->setObjectName(QStringLiteral("progressBar"));
        progressBar->setEnabled(true);
        progressBar->setValue(0);

        gridLayout->addWidget(progressBar, 24, 0, 1, 4);

        labelDRENValue = new QLabel(Dem2HandDialog);
        labelDRENValue->setObjectName(QStringLiteral("labelDRENValue"));

        gridLayout->addWidget(labelDRENValue, 13, 2, 1, 1);

        label_6 = new QLabel(Dem2HandDialog);
        label_6->setObjectName(QStringLiteral("label_6"));

        gridLayout->addWidget(label_6, 12, 0, 1, 1);

        radioButtonBreaching = new QRadioButton(Dem2HandDialog);
        radioButtonBreaching->setObjectName(QStringLiteral("radioButtonBreaching"));

        gridLayout->addWidget(radioButtonBreaching, 4, 2, 1, 1);

        label = new QLabel(Dem2HandDialog);
        label->setObjectName(QStringLiteral("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        lineEdit_LDD = new QLineEdit(Dem2HandDialog);
        lineEdit_LDD->setObjectName(QStringLiteral("lineEdit_LDD"));

        gridLayout->addWidget(lineEdit_LDD, 5, 2, 1, 1);

        line_3 = new QFrame(Dem2HandDialog);
        line_3->setObjectName(QStringLiteral("line_3"));
        line_3->setMinimumSize(QSize(0, 10));
        line_3->setFrameShape(QFrame::HLine);
        line_3->setFrameShadow(QFrame::Sunken);

        gridLayout->addWidget(line_3, 10, 0, 1, 4);

        spinBoxThreshold = new QSpinBox(Dem2HandDialog);
        spinBoxThreshold->setObjectName(QStringLiteral("spinBoxThreshold"));
        spinBoxThreshold->setMinimum(1);
        spinBoxThreshold->setMaximum(9999999);

        gridLayout->addWidget(spinBoxThreshold, 12, 2, 1, 1);

        lineEdit_HANDC = new QLineEdit(Dem2HandDialog);
        lineEdit_HANDC->setObjectName(QStringLiteral("lineEdit_HANDC"));
        lineEdit_HANDC->setEnabled(false);

        gridLayout->addWidget(lineEdit_HANDC, 21, 2, 1, 1);

        pushButton_Out_HANDC = new QPushButton(Dem2HandDialog);
        pushButton_Out_HANDC->setObjectName(QStringLiteral("pushButton_Out_HANDC"));
        pushButton_Out_HANDC->setEnabled(false);

        gridLayout->addWidget(pushButton_Out_HANDC, 21, 3, 1, 1);

        label_7 = new QLabel(Dem2HandDialog);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setEnabled(false);

        gridLayout->addWidget(label_7, 21, 0, 1, 1);

        labelEventName = new QLabel(Dem2HandDialog);
        labelEventName->setObjectName(QStringLiteral("labelEventName"));
        QFont font;
        font.setPointSize(11);
        labelEventName->setFont(font);

        gridLayout->addWidget(labelEventName, 23, 0, 1, 4);

        checkBoxOnlyHAND = new QCheckBox(Dem2HandDialog);
        checkBoxOnlyHAND->setObjectName(QStringLiteral("checkBoxOnlyHAND"));
        checkBoxOnlyHAND->setChecked(true);

        gridLayout->addWidget(checkBoxOnlyHAND, 25, 0, 1, 4);

        groupBox = new QGroupBox(Dem2HandDialog);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        horizontalLayout = new QHBoxLayout(groupBox);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        pushButtonFechar = new QPushButton(groupBox);
        pushButtonFechar->setObjectName(QStringLiteral("pushButtonFechar"));

        horizontalLayout->addWidget(pushButtonFechar);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        pushButtonCancel = new QPushButton(groupBox);
        pushButtonCancel->setObjectName(QStringLiteral("pushButtonCancel"));

        horizontalLayout->addWidget(pushButtonCancel);

        pushButtonOK = new QPushButton(groupBox);
        pushButtonOK->setObjectName(QStringLiteral("pushButtonOK"));

        horizontalLayout->addWidget(pushButtonOK);


        gridLayout->addWidget(groupBox, 26, 0, 1, 4);

        line_2 = new QFrame(Dem2HandDialog);
        line_2->setObjectName(QStringLiteral("line_2"));
        line_2->setMinimumSize(QSize(0, 10));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);

        gridLayout->addWidget(line_2, 8, 0, 1, 4);

        pushButton_In_DEM = new QPushButton(Dem2HandDialog);
        pushButton_In_DEM->setObjectName(QStringLiteral("pushButton_In_DEM"));

        gridLayout->addWidget(pushButton_In_DEM, 0, 3, 1, 1);

        pushButton_Out_DREN = new QPushButton(Dem2HandDialog);
        pushButton_Out_DREN->setObjectName(QStringLiteral("pushButton_Out_DREN"));

        gridLayout->addWidget(pushButton_Out_DREN, 11, 3, 1, 1);

        label_9 = new QLabel(Dem2HandDialog);
        label_9->setObjectName(QStringLiteral("label_9"));

        gridLayout->addWidget(label_9, 2, 0, 1, 1);

        lineEdit_HAND = new QLineEdit(Dem2HandDialog);
        lineEdit_HAND->setObjectName(QStringLiteral("lineEdit_HAND"));

        gridLayout->addWidget(lineEdit_HAND, 19, 2, 1, 1);

        pushButton_Out_HAND = new QPushButton(Dem2HandDialog);
        pushButton_Out_HAND->setObjectName(QStringLiteral("pushButton_Out_HAND"));

        gridLayout->addWidget(pushButton_Out_HAND, 19, 3, 1, 1);

        QWidget::setTabOrder(lineEdit_DEM, pushButton_In_DEM);
        QWidget::setTabOrder(pushButton_In_DEM, radioButtonFill);
        QWidget::setTabOrder(radioButtonFill, radioButtonBreaching);
        QWidget::setTabOrder(radioButtonBreaching, lineEdit_LDD);
        QWidget::setTabOrder(lineEdit_LDD, pushButton_Out_LDD);
        QWidget::setTabOrder(pushButton_Out_LDD, lineEdit_DEMC);
        QWidget::setTabOrder(lineEdit_DEMC, pushButton_Out_DEM);
        QWidget::setTabOrder(pushButton_Out_DEM, lineEdit_ACC);
        QWidget::setTabOrder(lineEdit_ACC, pushButton_Out_ACC);
        QWidget::setTabOrder(pushButton_Out_ACC, lineEdit_DREN);
        QWidget::setTabOrder(lineEdit_DREN, pushButton_Out_DREN);
        QWidget::setTabOrder(pushButton_Out_DREN, spinBoxThreshold);
        QWidget::setTabOrder(spinBoxThreshold, pushButtonOK);
        QWidget::setTabOrder(pushButtonOK, pushButtonCancel);

        retranslateUi(Dem2HandDialog);

        QMetaObject::connectSlotsByName(Dem2HandDialog);
    } // setupUi

    void retranslateUi(QDialog *Dem2HandDialog)
    {
        Dem2HandDialog->setWindowTitle(QApplication::translate("Dem2HandDialog", "Dialog", Q_NULLPTR));
        pushButton_Out_DEM->setText(QApplication::translate("Dem2HandDialog", "Select...", Q_NULLPTR));
        label_2->setText(QApplication::translate("Dem2HandDialog", "Output LDD", Q_NULLPTR));
        label_5->setText(QApplication::translate("Dem2HandDialog", "Output HAND", Q_NULLPTR));
        label_3->setText(QApplication::translate("Dem2HandDialog", "Output ACC", Q_NULLPTR));
        label_8->setText(QApplication::translate("Dem2HandDialog", "Output DEMC", Q_NULLPTR));
        label_4->setText(QApplication::translate("Dem2HandDialog", "Output DREN", Q_NULLPTR));
        pushButton_Out_LDD->setText(QApplication::translate("Dem2HandDialog", "Select...", Q_NULLPTR));
        pushButton_Out_ACC->setText(QApplication::translate("Dem2HandDialog", "Select...", Q_NULLPTR));
        radioButtonFill->setText(QApplication::translate("Dem2HandDialog", "Fill", Q_NULLPTR));
        labelDRENValue->setText(QString());
        label_6->setText(QApplication::translate("Dem2HandDialog", "Threshold", Q_NULLPTR));
        radioButtonBreaching->setText(QApplication::translate("Dem2HandDialog", "Breaching", Q_NULLPTR));
        label->setText(QApplication::translate("Dem2HandDialog", "Input DEM", Q_NULLPTR));
        pushButton_Out_HANDC->setText(QApplication::translate("Dem2HandDialog", "Select...", Q_NULLPTR));
        label_7->setText(QApplication::translate("Dem2HandDialog", "HAND Contour", Q_NULLPTR));
        labelEventName->setText(QString());
#ifndef QT_NO_TOOLTIP
        checkBoxOnlyHAND->setToolTip(QApplication::translate("Dem2HandDialog", "if checked, only the HAND final image will be created", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        checkBoxOnlyHAND->setText(QApplication::translate("Dem2HandDialog", "HAND image only", Q_NULLPTR));
        groupBox->setTitle(QString());
        pushButtonFechar->setText(QApplication::translate("Dem2HandDialog", "Close", Q_NULLPTR));
        pushButtonCancel->setText(QApplication::translate("Dem2HandDialog", "Cancel", Q_NULLPTR));
        pushButtonOK->setText(QApplication::translate("Dem2HandDialog", "Ok", Q_NULLPTR));
        pushButton_In_DEM->setText(QApplication::translate("Dem2HandDialog", "Select...", Q_NULLPTR));
        pushButton_Out_DREN->setText(QApplication::translate("Dem2HandDialog", "Select...", Q_NULLPTR));
        label_9->setText(QApplication::translate("Dem2HandDialog", "Algorithm", Q_NULLPTR));
        pushButton_Out_HAND->setText(QApplication::translate("Dem2HandDialog", "Select...", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Dem2HandDialog: public Ui_Dem2HandDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DEM2HANDDIALOG_H
