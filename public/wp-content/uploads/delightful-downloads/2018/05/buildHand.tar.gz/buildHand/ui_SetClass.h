/********************************************************************************
** Form generated from reading UI file 'SetClass.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SETCLASS_H
#define UI_SETCLASS_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_SetClass
{
public:
    QVBoxLayout *verticalLayout;
    QGroupBox *groupBox;
    QGridLayout *gridLayout;
    QLabel *labelPbInfo;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *SetClass)
    {
        if (SetClass->objectName().isEmpty())
            SetClass->setObjectName(QStringLiteral("SetClass"));
        SetClass->resize(450, 350);
        verticalLayout = new QVBoxLayout(SetClass);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        groupBox = new QGroupBox(SetClass);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        gridLayout = new QGridLayout(groupBox);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));

        verticalLayout->addWidget(groupBox);

        labelPbInfo = new QLabel(SetClass);
        labelPbInfo->setObjectName(QStringLiteral("labelPbInfo"));

        verticalLayout->addWidget(labelPbInfo);

        buttonBox = new QDialogButtonBox(SetClass);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel);

        verticalLayout->addWidget(buttonBox);


        retranslateUi(SetClass);
        QObject::connect(buttonBox, SIGNAL(accepted()), SetClass, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), SetClass, SLOT(reject()));

        QMetaObject::connectSlotsByName(SetClass);
    } // setupUi

    void retranslateUi(QDialog *SetClass)
    {
        SetClass->setWindowTitle(QApplication::translate("SetClass", "Dialog", Q_NULLPTR));
        groupBox->setTitle(QApplication::translate("SetClass", "Select Image Class", Q_NULLPTR));
        labelPbInfo->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class SetClass: public Ui_SetClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SETCLASS_H
